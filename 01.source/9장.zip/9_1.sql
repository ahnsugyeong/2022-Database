show databases;

use mysql;

show tables;

desc user;

select * from user;
