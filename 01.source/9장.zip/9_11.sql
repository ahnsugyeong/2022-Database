
use madang;

show tables;

select * from orders;

drop table orders;
drop table customer;
drop table book;
drop table imported_book;

