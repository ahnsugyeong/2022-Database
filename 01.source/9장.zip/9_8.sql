REVOKE SELECT ON madang.Book FROM mdguest@localhost;
