   USE madang;
   SELECT * FROM Customer;