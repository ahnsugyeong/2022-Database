
Use madang;
SELECT * FROM Book;

-- 아래의 명령어는 error 가 나옵니다!
insert into book values (11,'테스트','나무수',20000);


