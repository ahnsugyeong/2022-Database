-- madang 계정

GRANT SELECT ON madang.Book TO mdguest@localhost; 
