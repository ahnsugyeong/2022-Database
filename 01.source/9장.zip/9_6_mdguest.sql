
use madang;

select * from customer;

